App({
    onLaunch() {
      // 模拟用户信息（实际需登录态管理）
      this.globalData.user = {
        wechat: 'wxid_dev_demo', // 模拟原主微信
        studentId: '',          // 学号认证状态
        publishedItems: []      // 我的发布
      };
      // 模拟物品数据（实际需对接后端）
      this.globalData.items = [
        {
          id: 1,
          image: '/images/wupin/wp1.png',
          name: 'MacBook Air 2020',
          category: '电子',
          tag: '笔记本,闲置',
          desc: '9成新，无拆修，附赠电脑包',
          ownerWechat: 'wxid_abc123'
        },
        {
          id: 2,
          image: '/images/wupin/wp2.jpg',
          name: '村上春树作品集',
          category: '书籍',
          tag: '文学,小说',
          desc: '含《挪威的森林》《海边的卡夫卡》等6本',
          ownerWechat: 'wxid_def456'
        },
        // 3. Switch 续航版（电子）
        { 
          id: 3, 
          image: '/images/wupin/wp3.webp', 
          name: 'Switch 续航版', 
          desc: '含塞尔达、奥德赛，95新', 
          category: '电子', 
          tag: '闲置', 
          ownerWechat: 'wx_yw2025'
        },
        // 4. 机械键盘（电子）
        { 
          id: 4, 
          image: '/images/wupin/wp4.webp', 
          name: '机械键盘', 
          desc: '青轴，104键，自定义灯效', 
          category: '电子', 
          tag: '全新', 
          ownerWechat: 'wx_yw2025'
        },
        // 5. iPad Air 5（电子）
        { 
          id: 5, 
          image: '/images/wupin/wp5.webp', 
          name: 'iPad Air 5', 
          desc: '64G，深空灰，带笔', 
          category: '电子', 
          tag: '闲置', 
          ownerWechat: 'wx_yw2025'
        },
        // 6. 无线降噪耳机（电子）
        { 
          id: 6, 
          image: '/images/wupin/wp6.webp', 
          name: '无线降噪耳机', 
          desc: '主动降噪，续航20小时', 
          category: '电子', 
          tag: '闲置', 
          ownerWechat: 'wx_yw2025'
        },
        // 7. 健身环大冒险（二次元）
        { 
          id: 7, 
          image: '/images/wupin/wp7.webp', 
          name: '健身环大冒险', 
          desc: 'Switch配件，几乎全新', 
          category: '二次元',      // 对应分类：二次元
          tag: '全新', 
          ownerWechat: 'wx_yw2025'
        },
        // 8. 精装版四大名著（书籍）
        { 
          id: 8, 
          image: '/images/wupin/wp8.webp', 
          name: '精装版四大名著', 
          desc: '硬壳装订，收藏版', 
          category: '书籍', 
          tag: '闲置', 
          ownerWechat: 'wx_yw2025'
        }
      ];
    },
    globalData: {
      user:{
          username: '',
          studentId:''
      },
      items: []
    }
  });
  