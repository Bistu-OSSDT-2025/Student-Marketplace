Page({
    data: {
      searchKey: '',
      categories: ['书籍', '电子', '服饰', '生活', '二次元', '其他'], 
      leftCategories: [], // 左列数据（新增定义）
      rightCategories: [], // 右列数据（新增定义）
      filteredItems: []
    },
    onLoad() {
      // 1. 分割分类为左列（前3个）和右列（后3个）
      const left = this.data.categories.slice(0, 3); // 书籍、电子、服饰
      const right = this.data.categories.slice(3);    // 生活、二次元、其他
      
      // 2. 初始化物品数据 + 分类数据
      this.setData({ 
        leftCategories: left, 
        rightCategories: right,
        filteredItems: getApp().globalData.items 
      });
    },
    onSearchInput(e) {
      this.setData({ searchKey: e.detail.value });
    },
    onSearch() {
      const app = getApp();
      const filtered = app.globalData.items.filter(item => 
        item.name.includes(this.data.searchKey) || item.desc.includes(this.data.searchKey)
      );
      this.setData({ filteredItems: filtered });
    },

    // 点击物品卡片跳转到详情页
    goToDetail(e) {
      const itemId = e.currentTarget.dataset.id; // 获取物品 ID
      wx.navigateTo({
        url: `/pages/itemDetail/itemDetail?id=${itemId}`, // 跳转到详情页，传递 ID 参数
      });
    }
  });
  