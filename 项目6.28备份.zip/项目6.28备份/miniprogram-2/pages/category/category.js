Page({
    data: {
      currentCategory: '',
      filteredItems: []
    },
    onLoad(options) {
      const category = options.type || '全部';
      this.setData({ currentCategory: category });
      
      const app = getApp();
      let filtered = app.globalData.items;
      if (category !== '全部') {
        filtered = filtered.filter(item => item.category === category);
      }
      this.setData({ filteredItems: filtered });
    }
  });
  