Page({
    data: {
      studentId: '',
      isAuth: false,
      showAuthModal: false, // 控制弹窗显示
      studentIdInput: ''    // 输入框内容（双向绑定）
    },
    onLoad() {
      const app = getApp();
      this.setData({ 
        studentId: app.globalData.user.studentId,
        isAuth: !!app.globalData.user.studentId 
      });
    },
  
    // 点击“学号认证”，显示自定义弹窗
    authStudent() {
      this.setData({ showAuthModal: true });
    },
  
    // 输入学号（双向绑定）
    onStudentIdInput(e) {
      this.setData({ studentIdInput: e.detail.value });
    },
  
    // 取消认证，隐藏弹窗
    hideAuthModal() {
      this.setData({ showAuthModal: false, studentIdInput: '' });
    },
  
    // 确认认证
    confirmAuth() {
      const studentId = this.data.studentIdInput;
      if (!studentId) { // 校验非空
        wx.showToast({ title: '请输入学号', icon: 'none' });
        return;
      }
      // 更新全局用户信息（模拟，实际需调用后端接口）
      const app = getApp();
      app.globalData.user.studentId = studentId;
      this.setData({ 
        studentId: studentId, 
        isAuth: true,
        showAuthModal: false,
        studentIdInput: ''
      });
      wx.showToast({ title: '认证成功' });
    }
  });