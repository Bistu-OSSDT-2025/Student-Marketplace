App({
    onLaunch() {
      // 模拟用户信息（实际需登录态管理）
      this.globalData.user = {
        wechat: 'wxid_dev_demo', // 模拟原主微信
        studentId: '',          // 学号认证状态
        publishedItems: []      // 我的发布
      };
      // 模拟物品数据（实际需对接后端）
      this.globalData.items = [
        {
          id: 1,
          image: 'https://via.placeholder.com/375x300?text=二手笔记本',
          name: 'MacBook Air 2020',
          category: '电子',
          tag: '笔记本,闲置',
          desc: '9成新，无拆修，附赠电脑包',
          ownerWechat: 'wxid_abc123'
        },
        {
          id: 2,
          image: 'https://via.placeholder.com/375x300?text=文学书籍',
          name: '村上春树作品集',
          category: '书籍',
          tag: '文学,小说',
          desc: '含《挪威的森林》《海边的卡夫卡》等5本',
          ownerWechat: 'wxid_def456'
        }
      ];
    },
    globalData: {
      user: null,
      items: []
    }
  });
  